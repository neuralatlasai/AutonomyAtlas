# Agentic State: cumulative Chapters 1-34

Literature and implementation review: 2026-10-29. All 34 chapters, the conventional monograph driver, combined and input bibliographies, public build/validation/package tools, configuration, research maps, active figures, original prompts and declared generated edit inputs are included.

Build from the extracted source root:

    python tools/build_book.py
    python tools/validate_book.py --require-current-build

    # Alternatively rebuild the dated cumulative edition:
    python tools/build_review.py --through C34
    python tools/package_review.py --through C34

Requirements: Python 3.10+, pdfLaTeX, BibTeX, IEEEtran bibliography style, Latin Modern and the declared TeX packages. Python tooling uses PyMuPDF, pypdf and Pillow. Compilation uses no network service or API credentials; install external dependencies before building.

The distributed section inventory is already synchronized. The normal rebuild starts with build_book.py. The legacy sync_book.py migration helper can write chapter drivers and modules; it is not needed to rebuild this archive. Source packaging with package_review.py follows a build_review.py run and retains declared figure edit inputs.

Generated output directories are created by the tools. Prior PDFs, archives, build intermediates, supplied corpus, private research ledgers and caches are not distributed. The source manifest hashes the exact bytes of every payload member except itself, including prompts, edit inputs and the scoped figure manifest.

Compilation and mechanical validation do not establish visual fidelity or scientific validity. Body-page accounting excludes front matter and references and requires final review. Source/code inspection is not experimental reproduction. Original explanatory illustrations use the built-in image-generation tool; its exact model identifier was not exposed.
